﻿namespace PharmacyManagementSystem
{
    partial class SaleS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.ProductNamecomboBox = new System.Windows.Forms.ComboBox();
            this.QtytextBox = new System.Windows.Forms.TextBox();
            this.PricetextBox = new System.Windows.Forms.TextBox();
            this.CheckOutbutton = new System.Windows.Forms.Button();
            this.SubTotaltextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Addbutton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Pricelabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.PNamelabel = new System.Windows.Forms.Label();
            this.LowStocklabel = new System.Windows.Forms.Label();
            this.QtyValidationlabel = new System.Windows.Forms.Label();
            this.SubTotallabel = new System.Windows.Forms.Label();
            this.Qtylabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.USerNAmelabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.SavePurchasebutton = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BlancetextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.NetPaytextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.NetTotaltextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.DistextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Blancelabel = new System.Windows.Forms.Label();
            this.NetPaylabel = new System.Windows.Forms.Label();
            this.NetTotallabel = new System.Windows.Forms.Label();
            this.Dislabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.PIDDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNameDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PriceDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QtyDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalAmountDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Leftpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.Leftpanel.Controls.Add(this.ProductNamecomboBox);
            this.Leftpanel.Controls.Add(this.QtytextBox);
            this.Leftpanel.Controls.Add(this.PricetextBox);
            this.Leftpanel.Controls.Add(this.CheckOutbutton);
            this.Leftpanel.Controls.Add(this.SubTotaltextBox);
            this.Leftpanel.Controls.Add(this.label6);
            this.Leftpanel.Controls.Add(this.label4);
            this.Leftpanel.Controls.Add(this.Addbutton);
            this.Leftpanel.Controls.Add(this.label7);
            this.Leftpanel.Controls.Add(this.Pricelabel);
            this.Leftpanel.Controls.Add(this.label5);
            this.Leftpanel.Controls.Add(this.panel3);
            this.Leftpanel.Controls.Add(this.panel1);
            this.Leftpanel.Controls.Add(this.PNamelabel);
            this.Leftpanel.Controls.Add(this.LowStocklabel);
            this.Leftpanel.Controls.Add(this.QtyValidationlabel);
            this.Leftpanel.Controls.Add(this.SubTotallabel);
            this.Leftpanel.Controls.Add(this.Qtylabel);
            this.Leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Leftpanel.ForeColor = System.Drawing.Color.White;
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(200, 617);
            this.Leftpanel.TabIndex = 2;
            // 
            // ProductNamecomboBox
            // 
            this.ProductNamecomboBox.FormattingEnabled = true;
            this.ProductNamecomboBox.Location = new System.Drawing.Point(5, 176);
            this.ProductNamecomboBox.Name = "ProductNamecomboBox";
            this.ProductNamecomboBox.Size = new System.Drawing.Size(187, 21);
            this.ProductNamecomboBox.TabIndex = 62;
            this.ProductNamecomboBox.SelectedIndexChanged += new System.EventHandler(this.ProductNamecomboBox_SelectedIndexChanged);
            this.ProductNamecomboBox.Enter += new System.EventHandler(this.ProductNamecomboBox_Enter);
            // 
            // QtytextBox
            // 
            this.QtytextBox.Location = new System.Drawing.Point(5, 259);
            this.QtytextBox.Name = "QtytextBox";
            this.QtytextBox.Size = new System.Drawing.Size(187, 20);
            this.QtytextBox.TabIndex = 61;
            this.QtytextBox.TextChanged += new System.EventHandler(this.QtytextBox_TextChanged);
            // 
            // PricetextBox
            // 
            this.PricetextBox.Enabled = false;
            this.PricetextBox.Location = new System.Drawing.Point(5, 219);
            this.PricetextBox.Name = "PricetextBox";
            this.PricetextBox.Size = new System.Drawing.Size(187, 20);
            this.PricetextBox.TabIndex = 60;
            // 
            // CheckOutbutton
            // 
            this.CheckOutbutton.FlatAppearance.BorderSize = 2;
            this.CheckOutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckOutbutton.Location = new System.Drawing.Point(8, 449);
            this.CheckOutbutton.Name = "CheckOutbutton";
            this.CheckOutbutton.Size = new System.Drawing.Size(187, 48);
            this.CheckOutbutton.TabIndex = 56;
            this.CheckOutbutton.Text = "Check Out";
            this.CheckOutbutton.UseVisualStyleBackColor = true;
            this.CheckOutbutton.Click += new System.EventHandler(this.CheckOutbutton_Click);
            // 
            // SubTotaltextBox
            // 
            this.SubTotaltextBox.BackColor = System.Drawing.Color.White;
            this.SubTotaltextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SubTotaltextBox.Cursor = System.Windows.Forms.Cursors.No;
            this.SubTotaltextBox.Enabled = false;
            this.SubTotaltextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubTotaltextBox.ForeColor = System.Drawing.Color.Red;
            this.SubTotaltextBox.Location = new System.Drawing.Point(4, 364);
            this.SubTotaltextBox.Multiline = true;
            this.SubTotaltextBox.Name = "SubTotaltextBox";
            this.SubTotaltextBox.Size = new System.Drawing.Size(185, 47);
            this.SubTotaltextBox.TabIndex = 50;
            this.SubTotaltextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 348);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 49;
            this.label6.Text = "Sub Total";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 41;
            this.label4.Text = "Qty";
            // 
            // Addbutton
            // 
            this.Addbutton.FlatAppearance.BorderSize = 2;
            this.Addbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbutton.Location = new System.Drawing.Point(5, 308);
            this.Addbutton.Name = "Addbutton";
            this.Addbutton.Size = new System.Drawing.Size(187, 32);
            this.Addbutton.TabIndex = 40;
            this.Addbutton.Text = "Add";
            this.Addbutton.UseVisualStyleBackColor = true;
            this.Addbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 37;
            this.label7.Text = "Price";
            // 
            // Pricelabel
            // 
            this.Pricelabel.AutoSize = true;
            this.Pricelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pricelabel.ForeColor = System.Drawing.Color.Red;
            this.Pricelabel.Location = new System.Drawing.Point(176, 197);
            this.Pricelabel.Name = "Pricelabel";
            this.Pricelabel.Size = new System.Drawing.Size(18, 25);
            this.Pricelabel.TabIndex = 39;
            this.Pricelabel.Text = "!";
            this.Pricelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Pricelabel.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Select Product Name";
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 48);
            this.panel3.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 40);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.Backbutton.FlatAppearance.BorderSize = 0;
            this.Backbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOliveGreen;
            this.Backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Backbutton.Image = global::PharmacyManagementSystem.Properties.Resources.icons8_back_to_3636;
            this.Backbutton.Location = new System.Drawing.Point(0, 0);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(40, 40);
            this.Backbutton.TabIndex = 2;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // PNamelabel
            // 
            this.PNamelabel.AutoSize = true;
            this.PNamelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PNamelabel.ForeColor = System.Drawing.Color.Red;
            this.PNamelabel.Location = new System.Drawing.Point(176, 153);
            this.PNamelabel.Name = "PNamelabel";
            this.PNamelabel.Size = new System.Drawing.Size(18, 25);
            this.PNamelabel.TabIndex = 36;
            this.PNamelabel.Text = "!";
            this.PNamelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.PNamelabel.Visible = false;
            // 
            // LowStocklabel
            // 
            this.LowStocklabel.AutoSize = true;
            this.LowStocklabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LowStocklabel.ForeColor = System.Drawing.Color.Red;
            this.LowStocklabel.Location = new System.Drawing.Point(5, 416);
            this.LowStocklabel.Name = "LowStocklabel";
            this.LowStocklabel.Size = new System.Drawing.Size(0, 25);
            this.LowStocklabel.TabIndex = 57;
            this.LowStocklabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.LowStocklabel.Visible = false;
            // 
            // QtyValidationlabel
            // 
            this.QtyValidationlabel.AutoSize = true;
            this.QtyValidationlabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QtyValidationlabel.ForeColor = System.Drawing.Color.Red;
            this.QtyValidationlabel.Location = new System.Drawing.Point(3, 282);
            this.QtyValidationlabel.Name = "QtyValidationlabel";
            this.QtyValidationlabel.Size = new System.Drawing.Size(21, 25);
            this.QtyValidationlabel.TabIndex = 63;
            this.QtyValidationlabel.Text = "*";
            this.QtyValidationlabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.QtyValidationlabel.Visible = false;
            // 
            // SubTotallabel
            // 
            this.SubTotallabel.AutoSize = true;
            this.SubTotallabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubTotallabel.ForeColor = System.Drawing.Color.Red;
            this.SubTotallabel.Location = new System.Drawing.Point(174, 340);
            this.SubTotallabel.Name = "SubTotallabel";
            this.SubTotallabel.Size = new System.Drawing.Size(18, 25);
            this.SubTotallabel.TabIndex = 64;
            this.SubTotallabel.Text = "!";
            this.SubTotallabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.SubTotallabel.Visible = false;
            // 
            // Qtylabel
            // 
            this.Qtylabel.AutoSize = true;
            this.Qtylabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Qtylabel.ForeColor = System.Drawing.Color.Red;
            this.Qtylabel.Location = new System.Drawing.Point(173, 237);
            this.Qtylabel.Name = "Qtylabel";
            this.Qtylabel.Size = new System.Drawing.Size(18, 25);
            this.Qtylabel.TabIndex = 48;
            this.Qtylabel.Text = "!";
            this.Qtylabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Qtylabel.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel2.Controls.Add(this.USerNAmelabel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(883, 40);
            this.panel2.TabIndex = 3;
            // 
            // USerNAmelabel
            // 
            this.USerNAmelabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.USerNAmelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USerNAmelabel.Location = new System.Drawing.Point(501, 0);
            this.USerNAmelabel.Name = "USerNAmelabel";
            this.USerNAmelabel.Size = new System.Drawing.Size(382, 40);
            this.USerNAmelabel.TabIndex = 3;
            this.USerNAmelabel.Text = "User";
            this.USerNAmelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableLayoutPanel1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(200, 40);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(883, 48);
            this.panel4.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.Clearbutton, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.SavePurchasebutton, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(883, 48);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // Clearbutton
            // 
            this.Clearbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Clearbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Clearbutton.FlatAppearance.BorderSize = 2;
            this.Clearbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clearbutton.Location = new System.Drawing.Point(129, 3);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(120, 42);
            this.Clearbutton.TabIndex = 2;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // SavePurchasebutton
            // 
            this.SavePurchasebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SavePurchasebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SavePurchasebutton.FlatAppearance.BorderSize = 2;
            this.SavePurchasebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SavePurchasebutton.Location = new System.Drawing.Point(3, 3);
            this.SavePurchasebutton.Name = "SavePurchasebutton";
            this.SavePurchasebutton.Size = new System.Drawing.Size(120, 42);
            this.SavePurchasebutton.TabIndex = 1;
            this.SavePurchasebutton.Text = "Save";
            this.SavePurchasebutton.UseVisualStyleBackColor = true;
            this.SavePurchasebutton.Click += new System.EventHandler(this.SavePurchasebutton_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel5.Controls.Add(this.BlancetextBox);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.NetPaytextBox);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.NetTotaltextBox);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.DistextBox);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.Blancelabel);
            this.panel5.Controls.Add(this.NetPaylabel);
            this.panel5.Controls.Add(this.NetTotallabel);
            this.panel5.Controls.Add(this.Dislabel);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(200, 494);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(883, 123);
            this.panel5.TabIndex = 9;
            // 
            // BlancetextBox
            // 
            this.BlancetextBox.Enabled = false;
            this.BlancetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlancetextBox.Location = new System.Drawing.Point(684, 53);
            this.BlancetextBox.Multiline = true;
            this.BlancetextBox.Name = "BlancetextBox";
            this.BlancetextBox.Size = new System.Drawing.Size(187, 58);
            this.BlancetextBox.TabIndex = 62;
            this.BlancetextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BlancetextBox.Validated += new System.EventHandler(this.BlancetextBox_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(736, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 61;
            this.label1.Text = "Blance";
            // 
            // NetPaytextBox
            // 
            this.NetPaytextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPaytextBox.Location = new System.Drawing.Point(466, 52);
            this.NetPaytextBox.Multiline = true;
            this.NetPaytextBox.Name = "NetPaytextBox";
            this.NetPaytextBox.Size = new System.Drawing.Size(187, 58);
            this.NetPaytextBox.TabIndex = 60;
            this.NetPaytextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NetPaytextBox.TextChanged += new System.EventHandler(this.NetPaytextBox_TextChanged);
            this.NetPaytextBox.Validated += new System.EventHandler(this.NetPaytextBox_Validated);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(523, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 59;
            this.label15.Text = "Net Pay";
            // 
            // NetTotaltextBox
            // 
            this.NetTotaltextBox.Enabled = false;
            this.NetTotaltextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetTotaltextBox.Location = new System.Drawing.Point(254, 52);
            this.NetTotaltextBox.Multiline = true;
            this.NetTotaltextBox.Name = "NetTotaltextBox";
            this.NetTotaltextBox.Size = new System.Drawing.Size(187, 58);
            this.NetTotaltextBox.TabIndex = 56;
            this.NetTotaltextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NetTotaltextBox.Validated += new System.EventHandler(this.NetTotaltextBox_Validated);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(311, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 55;
            this.label12.Text = "Net Total";
            // 
            // DistextBox
            // 
            this.DistextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DistextBox.Location = new System.Drawing.Point(35, 52);
            this.DistextBox.Multiline = true;
            this.DistextBox.Name = "DistextBox";
            this.DistextBox.Size = new System.Drawing.Size(187, 58);
            this.DistextBox.TabIndex = 54;
            this.DistextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.DistextBox.TextChanged += new System.EventHandler(this.DistextBox_TextChanged);
            this.DistextBox.Validated += new System.EventHandler(this.DistextBox_Validated);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(90, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 53;
            this.label11.Text = "Dis";
            // 
            // Blancelabel
            // 
            this.Blancelabel.AutoSize = true;
            this.Blancelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blancelabel.ForeColor = System.Drawing.Color.Red;
            this.Blancelabel.Location = new System.Drawing.Point(792, 14);
            this.Blancelabel.Name = "Blancelabel";
            this.Blancelabel.Size = new System.Drawing.Size(18, 25);
            this.Blancelabel.TabIndex = 66;
            this.Blancelabel.Text = "!";
            this.Blancelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Blancelabel.Visible = false;
            // 
            // NetPaylabel
            // 
            this.NetPaylabel.AutoSize = true;
            this.NetPaylabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPaylabel.ForeColor = System.Drawing.Color.Red;
            this.NetPaylabel.Location = new System.Drawing.Point(590, 14);
            this.NetPaylabel.Name = "NetPaylabel";
            this.NetPaylabel.Size = new System.Drawing.Size(18, 25);
            this.NetPaylabel.TabIndex = 65;
            this.NetPaylabel.Text = "!";
            this.NetPaylabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.NetPaylabel.Visible = false;
            // 
            // NetTotallabel
            // 
            this.NetTotallabel.AutoSize = true;
            this.NetTotallabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetTotallabel.ForeColor = System.Drawing.Color.Red;
            this.NetTotallabel.Location = new System.Drawing.Point(383, 14);
            this.NetTotallabel.Name = "NetTotallabel";
            this.NetTotallabel.Size = new System.Drawing.Size(18, 25);
            this.NetTotallabel.TabIndex = 64;
            this.NetTotallabel.Text = "!";
            this.NetTotallabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.NetTotallabel.Visible = false;
            // 
            // Dislabel
            // 
            this.Dislabel.AutoSize = true;
            this.Dislabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dislabel.ForeColor = System.Drawing.Color.Red;
            this.Dislabel.Location = new System.Drawing.Point(118, 14);
            this.Dislabel.Name = "Dislabel";
            this.Dislabel.Size = new System.Drawing.Size(18, 25);
            this.Dislabel.TabIndex = 63;
            this.Dislabel.Text = "!";
            this.Dislabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Dislabel.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PIDDGV,
            this.PNameDGV,
            this.PriceDGV,
            this.QtyDGV,
            this.TotalAmountDGV,
            this.DeleteButton});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkOliveGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(200, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(883, 406);
            this.dataGridView1.TabIndex = 25;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // PIDDGV
            // 
            this.PIDDGV.HeaderText = "P ID";
            this.PIDDGV.Name = "PIDDGV";
            this.PIDDGV.ReadOnly = true;
            this.PIDDGV.Visible = false;
            // 
            // PNameDGV
            // 
            this.PNameDGV.HeaderText = "P Name";
            this.PNameDGV.Name = "PNameDGV";
            this.PNameDGV.ReadOnly = true;
            // 
            // PriceDGV
            // 
            this.PriceDGV.HeaderText = "Price";
            this.PriceDGV.Name = "PriceDGV";
            this.PriceDGV.ReadOnly = true;
            // 
            // QtyDGV
            // 
            this.QtyDGV.HeaderText = "Qty";
            this.QtyDGV.Name = "QtyDGV";
            this.QtyDGV.ReadOnly = true;
            // 
            // TotalAmountDGV
            // 
            this.TotalAmountDGV.HeaderText = "Total Amount";
            this.TotalAmountDGV.Name = "TotalAmountDGV";
            this.TotalAmountDGV.ReadOnly = true;
            // 
            // DeleteButton
            // 
            this.DeleteButton.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.DeleteButton.HeaderText = "Action";
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.ReadOnly = true;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseColumnTextForButtonValue = true;
            this.DeleteButton.Width = 46;
            // 
            // SaleS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 617);
            this.ControlBox = false;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Leftpanel);
            this.Name = "SaleS";
            this.ShowIcon = false;
            this.Text = "SaleS";
            this.Load += new System.EventHandler(this.SaleS_Load);
            this.Leftpanel.ResumeLayout(false);
            this.Leftpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Button CheckOutbutton;
        private System.Windows.Forms.TextBox SubTotaltextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Pricelabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.Label PNamelabel;
        private System.Windows.Forms.Label Qtylabel;
        private System.Windows.Forms.Label LowStocklabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label USerNAmelabel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button SavePurchasebutton;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox NetPaytextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox NetTotaltextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox DistextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox QtytextBox;
        private System.Windows.Forms.TextBox PricetextBox;
        private System.Windows.Forms.ComboBox ProductNamecomboBox;
        private System.Windows.Forms.TextBox BlancetextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label QtyValidationlabel;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIDDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNameDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn PriceDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn QtyDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalAmountDGV;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteButton;
        private System.Windows.Forms.Label Blancelabel;
        private System.Windows.Forms.Label NetPaylabel;
        private System.Windows.Forms.Label NetTotallabel;
        private System.Windows.Forms.Label Dislabel;
        private System.Windows.Forms.Label SubTotallabel;
    }
}