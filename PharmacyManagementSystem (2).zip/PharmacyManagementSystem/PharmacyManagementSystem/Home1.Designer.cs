﻿namespace PharmacyManagementSystem
{
    partial class Home1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LogOutbutton = new System.Windows.Forms.Button();
            this.SaleReturnbutton = new System.Windows.Forms.Button();
            this.SaleDetailsbutton = new System.Windows.Forms.Button();
            this.Salebutton = new System.Windows.Forms.Button();
            this.PurchaseDetailsbutton = new System.Windows.Forms.Button();
            this.Purchasebutton = new System.Windows.Forms.Button();
            this.Supplierbutton = new System.Windows.Forms.Button();
            this.Catagorybutton = new System.Windows.Forms.Button();
            this.Productsbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.UserIDlabel = new System.Windows.Forms.Label();
            this.Leftpanel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.Leftpanel.Controls.Add(this.tableLayoutPanel1);
            this.Leftpanel.Controls.Add(this.panel1);
            this.Leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Leftpanel.ForeColor = System.Drawing.Color.White;
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(200, 749);
            this.Leftpanel.TabIndex = 3;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.LogOutbutton, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.SaleReturnbutton, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.SaleDetailsbutton, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.Salebutton, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.PurchaseDetailsbutton, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.Purchasebutton, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Supplierbutton, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Catagorybutton, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Productsbutton, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 40);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 709);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // LogOutbutton
            // 
            this.LogOutbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LogOutbutton.FlatAppearance.BorderSize = 2;
            this.LogOutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogOutbutton.Location = new System.Drawing.Point(3, 627);
            this.LogOutbutton.Name = "LogOutbutton";
            this.LogOutbutton.Size = new System.Drawing.Size(194, 79);
            this.LogOutbutton.TabIndex = 8;
            this.LogOutbutton.Text = "Log Out";
            this.LogOutbutton.UseVisualStyleBackColor = true;
            this.LogOutbutton.Click += new System.EventHandler(this.LogOutbutton_Click);
            // 
            // SaleReturnbutton
            // 
            this.SaleReturnbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaleReturnbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SaleReturnbutton.FlatAppearance.BorderSize = 2;
            this.SaleReturnbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaleReturnbutton.Location = new System.Drawing.Point(3, 549);
            this.SaleReturnbutton.Name = "SaleReturnbutton";
            this.SaleReturnbutton.Size = new System.Drawing.Size(194, 72);
            this.SaleReturnbutton.TabIndex = 7;
            this.SaleReturnbutton.Text = "Sale Return";
            this.SaleReturnbutton.UseVisualStyleBackColor = true;
            this.SaleReturnbutton.Click += new System.EventHandler(this.SaleReturnbutton_Click);
            // 
            // SaleDetailsbutton
            // 
            this.SaleDetailsbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaleDetailsbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SaleDetailsbutton.FlatAppearance.BorderSize = 2;
            this.SaleDetailsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaleDetailsbutton.Location = new System.Drawing.Point(3, 471);
            this.SaleDetailsbutton.Name = "SaleDetailsbutton";
            this.SaleDetailsbutton.Size = new System.Drawing.Size(194, 72);
            this.SaleDetailsbutton.TabIndex = 6;
            this.SaleDetailsbutton.Text = "Sale Details";
            this.SaleDetailsbutton.UseVisualStyleBackColor = true;
            this.SaleDetailsbutton.Click += new System.EventHandler(this.SaleDetailsbutton_Click);
            // 
            // Salebutton
            // 
            this.Salebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Salebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Salebutton.FlatAppearance.BorderSize = 2;
            this.Salebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Salebutton.Location = new System.Drawing.Point(3, 393);
            this.Salebutton.Name = "Salebutton";
            this.Salebutton.Size = new System.Drawing.Size(194, 72);
            this.Salebutton.TabIndex = 5;
            this.Salebutton.Text = "Sale";
            this.Salebutton.UseVisualStyleBackColor = true;
            this.Salebutton.Click += new System.EventHandler(this.Salebutton_Click);
            // 
            // PurchaseDetailsbutton
            // 
            this.PurchaseDetailsbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PurchaseDetailsbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PurchaseDetailsbutton.FlatAppearance.BorderSize = 2;
            this.PurchaseDetailsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PurchaseDetailsbutton.Location = new System.Drawing.Point(3, 315);
            this.PurchaseDetailsbutton.Name = "PurchaseDetailsbutton";
            this.PurchaseDetailsbutton.Size = new System.Drawing.Size(194, 72);
            this.PurchaseDetailsbutton.TabIndex = 4;
            this.PurchaseDetailsbutton.Text = "Purchase Details";
            this.PurchaseDetailsbutton.UseVisualStyleBackColor = true;
            this.PurchaseDetailsbutton.Click += new System.EventHandler(this.PurchaseDetailsbutton_Click);
            // 
            // Purchasebutton
            // 
            this.Purchasebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Purchasebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Purchasebutton.FlatAppearance.BorderSize = 2;
            this.Purchasebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Purchasebutton.Location = new System.Drawing.Point(3, 237);
            this.Purchasebutton.Name = "Purchasebutton";
            this.Purchasebutton.Size = new System.Drawing.Size(194, 72);
            this.Purchasebutton.TabIndex = 3;
            this.Purchasebutton.Text = "Purchase";
            this.Purchasebutton.UseVisualStyleBackColor = true;
            this.Purchasebutton.Click += new System.EventHandler(this.Purchasebutton_Click);
            // 
            // Supplierbutton
            // 
            this.Supplierbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Supplierbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Supplierbutton.FlatAppearance.BorderSize = 2;
            this.Supplierbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Supplierbutton.Location = new System.Drawing.Point(3, 159);
            this.Supplierbutton.Name = "Supplierbutton";
            this.Supplierbutton.Size = new System.Drawing.Size(194, 72);
            this.Supplierbutton.TabIndex = 2;
            this.Supplierbutton.Text = "Supplier";
            this.Supplierbutton.UseVisualStyleBackColor = true;
            this.Supplierbutton.Click += new System.EventHandler(this.Supplierbutton_Click);
            // 
            // Catagorybutton
            // 
            this.Catagorybutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Catagorybutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Catagorybutton.FlatAppearance.BorderSize = 2;
            this.Catagorybutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Catagorybutton.Location = new System.Drawing.Point(3, 81);
            this.Catagorybutton.Name = "Catagorybutton";
            this.Catagorybutton.Size = new System.Drawing.Size(194, 72);
            this.Catagorybutton.TabIndex = 1;
            this.Catagorybutton.Text = "Catagory";
            this.Catagorybutton.UseVisualStyleBackColor = true;
            this.Catagorybutton.Click += new System.EventHandler(this.Catagorybutton_Click);
            // 
            // Productsbutton
            // 
            this.Productsbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Productsbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Productsbutton.FlatAppearance.BorderSize = 2;
            this.Productsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Productsbutton.Location = new System.Drawing.Point(3, 3);
            this.Productsbutton.Name = "Productsbutton";
            this.Productsbutton.Size = new System.Drawing.Size(194, 72);
            this.Productsbutton.TabIndex = 0;
            this.Productsbutton.Text = "Products";
            this.Productsbutton.UseVisualStyleBackColor = true;
            this.Productsbutton.Click += new System.EventHandler(this.Productsbutton_Click);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 40);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel2.Controls.Add(this.UserIDlabel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(805, 40);
            this.panel2.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(200, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(805, 709);
            this.panel3.TabIndex = 5;
            // 
            // UserIDlabel
            // 
            this.UserIDlabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.UserIDlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIDlabel.Location = new System.Drawing.Point(463, 0);
            this.UserIDlabel.Name = "UserIDlabel";
            this.UserIDlabel.Size = new System.Drawing.Size(342, 40);
            this.UserIDlabel.TabIndex = 4;
            this.UserIDlabel.Text = "User";
            this.UserIDlabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Home1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 749);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Leftpanel);
            this.Name = "Home1";
            this.ShowIcon = false;
            this.Text = "Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.Home1_Load);
            this.Leftpanel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button LogOutbutton;
        private System.Windows.Forms.Button SaleReturnbutton;
        private System.Windows.Forms.Button SaleDetailsbutton;
        private System.Windows.Forms.Button Salebutton;
        private System.Windows.Forms.Button PurchaseDetailsbutton;
        private System.Windows.Forms.Button Purchasebutton;
        private System.Windows.Forms.Button Supplierbutton;
        private System.Windows.Forms.Button Catagorybutton;
        private System.Windows.Forms.Button Productsbutton;
        private System.Windows.Forms.Label UserIDlabel;
    }
}