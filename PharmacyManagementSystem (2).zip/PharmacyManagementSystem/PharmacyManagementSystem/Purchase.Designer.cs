﻿namespace PharmacyManagementSystem
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.CheckOutbutton = new System.Windows.Forms.Button();
            this.SubTotaltextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ProductsNamecomboBox = new System.Windows.Forms.ComboBox();
            this.QtytextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Addbutton = new System.Windows.Forms.Button();
            this.PricetextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Pricelabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SupplierNamecomboBox = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.SupplierNamelabel = new System.Windows.Forms.Label();
            this.PNamelabel = new System.Windows.Forms.Label();
            this.Qtylabel = new System.Windows.Forms.Label();
            this.LowStocklabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.UserIDlabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.SavePurchasebutton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.PIDDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNameDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QtyDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PriceDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalAmountDGV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.DistextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.NetTotaltextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.NetPaytextBox = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Blancelabel = new System.Windows.Forms.Label();
            this.NetPaylabel = new System.Windows.Forms.Label();
            this.NetTotallabel = new System.Windows.Forms.Label();
            this.Dislabel = new System.Windows.Forms.Label();
            this.BlancetextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Leftpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.Leftpanel.Controls.Add(this.CheckOutbutton);
            this.Leftpanel.Controls.Add(this.SubTotaltextBox);
            this.Leftpanel.Controls.Add(this.label6);
            this.Leftpanel.Controls.Add(this.ProductsNamecomboBox);
            this.Leftpanel.Controls.Add(this.QtytextBox);
            this.Leftpanel.Controls.Add(this.label4);
            this.Leftpanel.Controls.Add(this.Addbutton);
            this.Leftpanel.Controls.Add(this.PricetextBox);
            this.Leftpanel.Controls.Add(this.label7);
            this.Leftpanel.Controls.Add(this.Pricelabel);
            this.Leftpanel.Controls.Add(this.label5);
            this.Leftpanel.Controls.Add(this.SupplierNamecomboBox);
            this.Leftpanel.Controls.Add(this.panel3);
            this.Leftpanel.Controls.Add(this.label2);
            this.Leftpanel.Controls.Add(this.panel1);
            this.Leftpanel.Controls.Add(this.SupplierNamelabel);
            this.Leftpanel.Controls.Add(this.PNamelabel);
            this.Leftpanel.Controls.Add(this.Qtylabel);
            this.Leftpanel.Controls.Add(this.LowStocklabel);
            this.Leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Leftpanel.ForeColor = System.Drawing.Color.White;
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(200, 663);
            this.Leftpanel.TabIndex = 1;
            this.Leftpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Leftpanel_Paint);
            // 
            // CheckOutbutton
            // 
            this.CheckOutbutton.FlatAppearance.BorderSize = 2;
            this.CheckOutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckOutbutton.Location = new System.Drawing.Point(4, 467);
            this.CheckOutbutton.Name = "CheckOutbutton";
            this.CheckOutbutton.Size = new System.Drawing.Size(187, 48);
            this.CheckOutbutton.TabIndex = 56;
            this.CheckOutbutton.Text = "Check Out";
            this.CheckOutbutton.UseVisualStyleBackColor = true;
            this.CheckOutbutton.Click += new System.EventHandler(this.CheckOutbutton_Click_1);
            // 
            // SubTotaltextBox
            // 
            this.SubTotaltextBox.BackColor = System.Drawing.Color.White;
            this.SubTotaltextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SubTotaltextBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SubTotaltextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubTotaltextBox.ForeColor = System.Drawing.Color.Black;
            this.SubTotaltextBox.Location = new System.Drawing.Point(4, 408);
            this.SubTotaltextBox.Multiline = true;
            this.SubTotaltextBox.Name = "SubTotaltextBox";
            this.SubTotaltextBox.ReadOnly = true;
            this.SubTotaltextBox.Size = new System.Drawing.Size(185, 47);
            this.SubTotaltextBox.TabIndex = 50;
            this.SubTotaltextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 392);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 49;
            this.label6.Text = "Sub Total";
            // 
            // ProductsNamecomboBox
            // 
            this.ProductsNamecomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ProductsNamecomboBox.FormattingEnabled = true;
            this.ProductsNamecomboBox.Location = new System.Drawing.Point(5, 240);
            this.ProductsNamecomboBox.Name = "ProductsNamecomboBox";
            this.ProductsNamecomboBox.Size = new System.Drawing.Size(187, 21);
            this.ProductsNamecomboBox.TabIndex = 45;
            this.ProductsNamecomboBox.SelectedIndexChanged += new System.EventHandler(this.ProductsNamecomboBox_SelectedIndexChanged);
            this.ProductsNamecomboBox.Enter += new System.EventHandler(this.ProductsNamecomboBox_Enter);
            this.ProductsNamecomboBox.Validated += new System.EventHandler(this.ProductsNamecomboBox_Validated);
            // 
            // QtytextBox
            // 
            this.QtytextBox.Location = new System.Drawing.Point(6, 321);
            this.QtytextBox.Name = "QtytextBox";
            this.QtytextBox.Size = new System.Drawing.Size(187, 20);
            this.QtytextBox.TabIndex = 42;
            this.QtytextBox.TextChanged += new System.EventHandler(this.QtytextBox_TextChanged);
            this.QtytextBox.Validated += new System.EventHandler(this.QtytextBox_Validated);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 41;
            this.label4.Text = "Qty";
            // 
            // Addbutton
            // 
            this.Addbutton.FlatAppearance.BorderSize = 2;
            this.Addbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbutton.Location = new System.Drawing.Point(5, 354);
            this.Addbutton.Name = "Addbutton";
            this.Addbutton.Size = new System.Drawing.Size(187, 32);
            this.Addbutton.TabIndex = 40;
            this.Addbutton.Text = "Add";
            this.Addbutton.UseVisualStyleBackColor = true;
            this.Addbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // PricetextBox
            // 
            this.PricetextBox.Location = new System.Drawing.Point(6, 283);
            this.PricetextBox.Name = "PricetextBox";
            this.PricetextBox.Size = new System.Drawing.Size(187, 20);
            this.PricetextBox.TabIndex = 38;
            this.PricetextBox.Validated += new System.EventHandler(this.PricetextBox_Validated);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 37;
            this.label7.Text = "Price";
            // 
            // Pricelabel
            // 
            this.Pricelabel.AutoSize = true;
            this.Pricelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pricelabel.ForeColor = System.Drawing.Color.Red;
            this.Pricelabel.Location = new System.Drawing.Point(176, 262);
            this.Pricelabel.Name = "Pricelabel";
            this.Pricelabel.Size = new System.Drawing.Size(21, 25);
            this.Pricelabel.TabIndex = 39;
            this.Pricelabel.Text = "*";
            this.Pricelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Pricelabel.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Select Product Name";
            // 
            // SupplierNamecomboBox
            // 
            this.SupplierNamecomboBox.FormattingEnabled = true;
            this.SupplierNamecomboBox.Location = new System.Drawing.Point(4, 192);
            this.SupplierNamecomboBox.Name = "SupplierNamecomboBox";
            this.SupplierNamecomboBox.Size = new System.Drawing.Size(187, 21);
            this.SupplierNamecomboBox.TabIndex = 31;
            this.SupplierNamecomboBox.SelectedIndexChanged += new System.EventHandler(this.SupplierNamecomboBox_SelectedIndexChanged);
            this.SupplierNamecomboBox.Enter += new System.EventHandler(this.SupplierNamecomboBox_Enter);
            this.SupplierNamecomboBox.Validated += new System.EventHandler(this.SupplierNamecomboBox_Validated);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 48);
            this.panel3.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Supplier Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 40);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.Backbutton.FlatAppearance.BorderSize = 0;
            this.Backbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOliveGreen;
            this.Backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Backbutton.Image = global::PharmacyManagementSystem.Properties.Resources.icons8_back_to_3636;
            this.Backbutton.Location = new System.Drawing.Point(0, 0);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(40, 40);
            this.Backbutton.TabIndex = 2;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // SupplierNamelabel
            // 
            this.SupplierNamelabel.AutoSize = true;
            this.SupplierNamelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierNamelabel.ForeColor = System.Drawing.Color.Red;
            this.SupplierNamelabel.Location = new System.Drawing.Point(172, 167);
            this.SupplierNamelabel.Name = "SupplierNamelabel";
            this.SupplierNamelabel.Size = new System.Drawing.Size(21, 25);
            this.SupplierNamelabel.TabIndex = 30;
            this.SupplierNamelabel.Text = "*";
            this.SupplierNamelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.SupplierNamelabel.Visible = false;
            // 
            // PNamelabel
            // 
            this.PNamelabel.AutoSize = true;
            this.PNamelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PNamelabel.ForeColor = System.Drawing.Color.Red;
            this.PNamelabel.Location = new System.Drawing.Point(173, 218);
            this.PNamelabel.Name = "PNamelabel";
            this.PNamelabel.Size = new System.Drawing.Size(21, 25);
            this.PNamelabel.TabIndex = 36;
            this.PNamelabel.Text = "*";
            this.PNamelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.PNamelabel.Visible = false;
            // 
            // Qtylabel
            // 
            this.Qtylabel.AutoSize = true;
            this.Qtylabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Qtylabel.ForeColor = System.Drawing.Color.Red;
            this.Qtylabel.Location = new System.Drawing.Point(173, 301);
            this.Qtylabel.Name = "Qtylabel";
            this.Qtylabel.Size = new System.Drawing.Size(21, 25);
            this.Qtylabel.TabIndex = 48;
            this.Qtylabel.Text = "*";
            this.Qtylabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Qtylabel.Visible = false;
            // 
            // LowStocklabel
            // 
            this.LowStocklabel.AutoSize = true;
            this.LowStocklabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LowStocklabel.ForeColor = System.Drawing.Color.Red;
            this.LowStocklabel.Location = new System.Drawing.Point(5, 405);
            this.LowStocklabel.Name = "LowStocklabel";
            this.LowStocklabel.Size = new System.Drawing.Size(0, 25);
            this.LowStocklabel.TabIndex = 57;
            this.LowStocklabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.LowStocklabel.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel2.Controls.Add(this.UserIDlabel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(883, 40);
            this.panel2.TabIndex = 2;
            // 
            // UserIDlabel
            // 
            this.UserIDlabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.UserIDlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIDlabel.Location = new System.Drawing.Point(501, 0);
            this.UserIDlabel.Name = "UserIDlabel";
            this.UserIDlabel.Size = new System.Drawing.Size(382, 40);
            this.UserIDlabel.TabIndex = 3;
            this.UserIDlabel.Text = "User";
            this.UserIDlabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tableLayoutPanel1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(200, 40);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(883, 48);
            this.panel6.TabIndex = 5;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.Clearbutton, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.SavePurchasebutton, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(883, 48);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // Clearbutton
            // 
            this.Clearbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Clearbutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Clearbutton.FlatAppearance.BorderSize = 2;
            this.Clearbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clearbutton.Location = new System.Drawing.Point(129, 3);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(120, 42);
            this.Clearbutton.TabIndex = 2;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // SavePurchasebutton
            // 
            this.SavePurchasebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SavePurchasebutton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SavePurchasebutton.FlatAppearance.BorderSize = 2;
            this.SavePurchasebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SavePurchasebutton.Location = new System.Drawing.Point(3, 3);
            this.SavePurchasebutton.Name = "SavePurchasebutton";
            this.SavePurchasebutton.Size = new System.Drawing.Size(120, 42);
            this.SavePurchasebutton.TabIndex = 1;
            this.SavePurchasebutton.Text = "Save";
            this.SavePurchasebutton.UseVisualStyleBackColor = true;
            this.SavePurchasebutton.Click += new System.EventHandler(this.SaveUserbutton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PIDDGV,
            this.PNameDGV,
            this.QtyDGV,
            this.PriceDGV,
            this.TotalAmountDGV,
            this.DeleteButton});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkOliveGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(200, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(883, 452);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // PIDDGV
            // 
            this.PIDDGV.HeaderText = "P ID";
            this.PIDDGV.Name = "PIDDGV";
            this.PIDDGV.ReadOnly = true;
            this.PIDDGV.Visible = false;
            // 
            // PNameDGV
            // 
            this.PNameDGV.HeaderText = "P Name";
            this.PNameDGV.Name = "PNameDGV";
            this.PNameDGV.ReadOnly = true;
            // 
            // QtyDGV
            // 
            this.QtyDGV.HeaderText = "Qty";
            this.QtyDGV.Name = "QtyDGV";
            this.QtyDGV.ReadOnly = true;
            // 
            // PriceDGV
            // 
            this.PriceDGV.HeaderText = "Price";
            this.PriceDGV.Name = "PriceDGV";
            this.PriceDGV.ReadOnly = true;
            // 
            // TotalAmountDGV
            // 
            this.TotalAmountDGV.HeaderText = "Total Amount";
            this.TotalAmountDGV.Name = "TotalAmountDGV";
            this.TotalAmountDGV.ReadOnly = true;
            // 
            // DeleteButton
            // 
            this.DeleteButton.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.DeleteButton.HeaderText = "Action";
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.ReadOnly = true;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseColumnTextForButtonValue = true;
            this.DeleteButton.Width = 46;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(95, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 53;
            this.label11.Text = "Dis";
            // 
            // DistextBox
            // 
            this.DistextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DistextBox.Location = new System.Drawing.Point(40, 52);
            this.DistextBox.Multiline = true;
            this.DistextBox.Name = "DistextBox";
            this.DistextBox.Size = new System.Drawing.Size(187, 58);
            this.DistextBox.TabIndex = 54;
            this.DistextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.DistextBox.TextChanged += new System.EventHandler(this.DistextBox_TextChanged);
            this.DistextBox.Validated += new System.EventHandler(this.DistextBox_Validated);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(318, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 55;
            this.label12.Text = "Net Total";
            // 
            // NetTotaltextBox
            // 
            this.NetTotaltextBox.Enabled = false;
            this.NetTotaltextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetTotaltextBox.Location = new System.Drawing.Point(261, 52);
            this.NetTotaltextBox.Multiline = true;
            this.NetTotaltextBox.Name = "NetTotaltextBox";
            this.NetTotaltextBox.Size = new System.Drawing.Size(187, 58);
            this.NetTotaltextBox.TabIndex = 56;
            this.NetTotaltextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(532, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 59;
            this.label15.Text = "Net Pay";
            // 
            // NetPaytextBox
            // 
            this.NetPaytextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPaytextBox.Location = new System.Drawing.Point(475, 52);
            this.NetPaytextBox.Multiline = true;
            this.NetPaytextBox.Name = "NetPaytextBox";
            this.NetPaytextBox.Size = new System.Drawing.Size(187, 58);
            this.NetPaytextBox.TabIndex = 60;
            this.NetPaytextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NetPaytextBox.TextChanged += new System.EventHandler(this.NetPaytextBox_TextChanged);
            this.NetPaytextBox.Validated += new System.EventHandler(this.NetPaytextBox_Validated);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel5.Controls.Add(this.Blancelabel);
            this.panel5.Controls.Add(this.NetPaylabel);
            this.panel5.Controls.Add(this.NetTotallabel);
            this.panel5.Controls.Add(this.Dislabel);
            this.panel5.Controls.Add(this.BlancetextBox);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.NetPaytextBox);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.NetTotaltextBox);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.DistextBox);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(200, 540);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(883, 123);
            this.panel5.TabIndex = 4;
            // 
            // Blancelabel
            // 
            this.Blancelabel.AutoSize = true;
            this.Blancelabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blancelabel.ForeColor = System.Drawing.Color.Red;
            this.Blancelabel.Location = new System.Drawing.Point(801, 17);
            this.Blancelabel.Name = "Blancelabel";
            this.Blancelabel.Size = new System.Drawing.Size(18, 25);
            this.Blancelabel.TabIndex = 67;
            this.Blancelabel.Text = "!";
            this.Blancelabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Blancelabel.Visible = false;
            // 
            // NetPaylabel
            // 
            this.NetPaylabel.AutoSize = true;
            this.NetPaylabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPaylabel.ForeColor = System.Drawing.Color.Red;
            this.NetPaylabel.Location = new System.Drawing.Point(583, 17);
            this.NetPaylabel.Name = "NetPaylabel";
            this.NetPaylabel.Size = new System.Drawing.Size(18, 25);
            this.NetPaylabel.TabIndex = 66;
            this.NetPaylabel.Text = "!";
            this.NetPaylabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.NetPaylabel.Visible = false;
            // 
            // NetTotallabel
            // 
            this.NetTotallabel.AutoSize = true;
            this.NetTotallabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetTotallabel.ForeColor = System.Drawing.Color.Red;
            this.NetTotallabel.Location = new System.Drawing.Point(375, 17);
            this.NetTotallabel.Name = "NetTotallabel";
            this.NetTotallabel.Size = new System.Drawing.Size(18, 25);
            this.NetTotallabel.TabIndex = 65;
            this.NetTotallabel.Text = "!";
            this.NetTotallabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.NetTotallabel.Visible = false;
            // 
            // Dislabel
            // 
            this.Dislabel.AutoSize = true;
            this.Dislabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dislabel.ForeColor = System.Drawing.Color.Red;
            this.Dislabel.Location = new System.Drawing.Point(124, 17);
            this.Dislabel.Name = "Dislabel";
            this.Dislabel.Size = new System.Drawing.Size(18, 25);
            this.Dislabel.TabIndex = 64;
            this.Dislabel.Text = "!";
            this.Dislabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Dislabel.Visible = false;
            // 
            // BlancetextBox
            // 
            this.BlancetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlancetextBox.Location = new System.Drawing.Point(688, 52);
            this.BlancetextBox.Multiline = true;
            this.BlancetextBox.Name = "BlancetextBox";
            this.BlancetextBox.ReadOnly = true;
            this.BlancetextBox.Size = new System.Drawing.Size(187, 58);
            this.BlancetextBox.TabIndex = 62;
            this.BlancetextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(745, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 61;
            this.label1.Text = "Blance";
            // 
            // Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 663);
            this.ControlBox = false;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Leftpanel);
            this.Name = "Purchase";
            this.ShowIcon = false;
            this.Text = "Purchase";
            this.Load += new System.EventHandler(this.Purchase_Load);
            this.Leftpanel.ResumeLayout(false);
            this.Leftpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.Label SupplierNamelabel;
        private System.Windows.Forms.ComboBox SupplierNamecomboBox;
        private System.Windows.Forms.TextBox PricetextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Pricelabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label PNamelabel;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.TextBox QtytextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label UserIDlabel;
        private System.Windows.Forms.ComboBox ProductsNamecomboBox;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label Qtylabel;
        private System.Windows.Forms.TextBox SubTotaltextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button CheckOutbutton;
        private System.Windows.Forms.Label LowStocklabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIDDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNameDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn QtyDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn PriceDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalAmountDGV;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteButton;
        private System.Windows.Forms.Button SavePurchasebutton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox DistextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox NetTotaltextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox NetPaytextBox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox BlancetextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Dislabel;
        private System.Windows.Forms.Label NetTotallabel;
        private System.Windows.Forms.Label NetPaylabel;
        private System.Windows.Forms.Label Blancelabel;
    }
}