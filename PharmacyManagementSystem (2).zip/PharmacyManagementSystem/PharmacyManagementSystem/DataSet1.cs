﻿namespace PharmacyManagementSystem {
    
    
    public partial class DataSet1 {
    }
}
namespace PharmacyManagementSystem {
    
    
    public partial class DataSet1 {
    }
}
