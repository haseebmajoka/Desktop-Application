﻿namespace PharmacyManagementSystem
{
    partial class SettingS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rightpanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.PasswordtextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.UserIDtextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Savebutton = new System.Windows.Forms.Button();
            this.DatabasetextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ServertextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Serverlabel = new System.Windows.Forms.Label();
            this.DataBaselabel = new System.Windows.Forms.Label();
            this.UserIDlabel = new System.Windows.Forms.Label();
            this.Passwordlabel = new System.Windows.Forms.Label();
            this.Rightpanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Leftpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Rightpanel
            // 
            this.Rightpanel.Controls.Add(this.panel2);
            this.Rightpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Rightpanel.Location = new System.Drawing.Point(200, 0);
            this.Rightpanel.Name = "Rightpanel";
            this.Rightpanel.Size = new System.Drawing.Size(857, 537);
            this.Rightpanel.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(857, 40);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(382, 40);
            this.label3.TabIndex = 3;
            this.label3.Text = "User";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.Leftpanel.Controls.Add(this.checkBox1);
            this.Leftpanel.Controls.Add(this.PasswordtextBox);
            this.Leftpanel.Controls.Add(this.label6);
            this.Leftpanel.Controls.Add(this.UserIDtextBox);
            this.Leftpanel.Controls.Add(this.label5);
            this.Leftpanel.Controls.Add(this.Savebutton);
            this.Leftpanel.Controls.Add(this.DatabasetextBox);
            this.Leftpanel.Controls.Add(this.label4);
            this.Leftpanel.Controls.Add(this.ServertextBox);
            this.Leftpanel.Controls.Add(this.label2);
            this.Leftpanel.Controls.Add(this.panel1);
            this.Leftpanel.Controls.Add(this.Serverlabel);
            this.Leftpanel.Controls.Add(this.DataBaselabel);
            this.Leftpanel.Controls.Add(this.UserIDlabel);
            this.Leftpanel.Controls.Add(this.Passwordlabel);
            this.Leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Leftpanel.ForeColor = System.Drawing.Color.White;
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(200, 537);
            this.Leftpanel.TabIndex = 2;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(9, 410);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(115, 17);
            this.checkBox1.TabIndex = 31;
            this.checkBox1.Text = "Integrated Security";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // PasswordtextBox
            // 
            this.PasswordtextBox.Location = new System.Drawing.Point(8, 376);
            this.PasswordtextBox.Name = "PasswordtextBox";
            this.PasswordtextBox.Size = new System.Drawing.Size(181, 20);
            this.PasswordtextBox.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 352);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Password";
            // 
            // UserIDtextBox
            // 
            this.UserIDtextBox.Location = new System.Drawing.Point(8, 322);
            this.UserIDtextBox.Name = "UserIDtextBox";
            this.UserIDtextBox.Size = new System.Drawing.Size(181, 20);
            this.UserIDtextBox.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 301);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "User ID";
            // 
            // Savebutton
            // 
            this.Savebutton.FlatAppearance.BorderSize = 2;
            this.Savebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Savebutton.Location = new System.Drawing.Point(9, 440);
            this.Savebutton.Name = "Savebutton";
            this.Savebutton.Size = new System.Drawing.Size(180, 35);
            this.Savebutton.TabIndex = 26;
            this.Savebutton.Text = "Save";
            this.Savebutton.UseVisualStyleBackColor = true;
            this.Savebutton.Click += new System.EventHandler(this.Savebutton_Click);
            // 
            // DatabasetextBox
            // 
            this.DatabasetextBox.Location = new System.Drawing.Point(7, 273);
            this.DatabasetextBox.Name = "DatabasetextBox";
            this.DatabasetextBox.Size = new System.Drawing.Size(181, 20);
            this.DatabasetextBox.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Database";
            // 
            // ServertextBox
            // 
            this.ServertextBox.Location = new System.Drawing.Point(6, 226);
            this.ServertextBox.Name = "ServertextBox";
            this.ServertextBox.Size = new System.Drawing.Size(181, 20);
            this.ServertextBox.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Server";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 40);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Serverlabel
            // 
            this.Serverlabel.AutoSize = true;
            this.Serverlabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serverlabel.ForeColor = System.Drawing.Color.Red;
            this.Serverlabel.Location = new System.Drawing.Point(55, 206);
            this.Serverlabel.Name = "Serverlabel";
            this.Serverlabel.Size = new System.Drawing.Size(22, 30);
            this.Serverlabel.TabIndex = 32;
            this.Serverlabel.Text = "*";
            this.Serverlabel.Visible = false;
            // 
            // DataBaselabel
            // 
            this.DataBaselabel.AutoSize = true;
            this.DataBaselabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataBaselabel.ForeColor = System.Drawing.Color.Red;
            this.DataBaselabel.Location = new System.Drawing.Point(55, 249);
            this.DataBaselabel.Name = "DataBaselabel";
            this.DataBaselabel.Size = new System.Drawing.Size(22, 30);
            this.DataBaselabel.TabIndex = 33;
            this.DataBaselabel.Text = "*";
            this.DataBaselabel.Visible = false;
            // 
            // UserIDlabel
            // 
            this.UserIDlabel.AutoSize = true;
            this.UserIDlabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIDlabel.ForeColor = System.Drawing.Color.Red;
            this.UserIDlabel.Location = new System.Drawing.Point(55, 301);
            this.UserIDlabel.Name = "UserIDlabel";
            this.UserIDlabel.Size = new System.Drawing.Size(22, 30);
            this.UserIDlabel.TabIndex = 34;
            this.UserIDlabel.Text = "*";
            this.UserIDlabel.Visible = false;
            // 
            // Passwordlabel
            // 
            this.Passwordlabel.AutoSize = true;
            this.Passwordlabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Passwordlabel.ForeColor = System.Drawing.Color.Red;
            this.Passwordlabel.Location = new System.Drawing.Point(55, 345);
            this.Passwordlabel.Name = "Passwordlabel";
            this.Passwordlabel.Size = new System.Drawing.Size(22, 30);
            this.Passwordlabel.TabIndex = 35;
            this.Passwordlabel.Text = "*";
            this.Passwordlabel.Visible = false;
            // 
            // SettingS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 537);
            this.ControlBox = false;
            this.Controls.Add(this.Rightpanel);
            this.Controls.Add(this.Leftpanel);
            this.Name = "SettingS";
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.SettingS_Load);
            this.Rightpanel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.Leftpanel.ResumeLayout(false);
            this.Leftpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Rightpanel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox PasswordtextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox UserIDtextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Savebutton;
        private System.Windows.Forms.TextBox DatabasetextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ServertextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Serverlabel;
        private System.Windows.Forms.Label Passwordlabel;
        private System.Windows.Forms.Label UserIDlabel;
        private System.Windows.Forms.Label DataBaselabel;

    }
}